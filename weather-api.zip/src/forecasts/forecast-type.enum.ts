export enum ForecastType {
    Sunny = 'Sunny',
    Cloudy = 'Cloudy',
    Stormy = 'Stormy'
}